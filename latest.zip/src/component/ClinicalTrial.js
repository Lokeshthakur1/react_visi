import React, { Component } from 'react'

export default class ClinicalTrial extends Component {
    render() {
        return (
            <div>
                <main>
                    <section className="py-5">
                        <div className="container">
                            <h4 className="title wow fadeIn font-weight-bold text-center" data-wow-delay="0.2s">CLINICAL TRIAL PLANNING
                            & EXECUTION

                                    </h4>
                            <img className="img-fluid" src="img/svg/clinical_trial-img.svg" />

                        </div>
                    </section>
                </main>
            </div>

        )

        {/* <!-- Main content --> */ }


    }
}
